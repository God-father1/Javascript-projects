# game
It's a simple memory programming game  made by using html, css, JavaScript.
